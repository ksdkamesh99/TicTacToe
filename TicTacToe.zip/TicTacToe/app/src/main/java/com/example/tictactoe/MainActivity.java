package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button start;
    EditText p1,p2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        start=(Button) findViewById(R.id.start);
        p1=(EditText) findViewById(R.id.p1);
        p2=(EditText) findViewById(R.id.p2);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(p1.getText().toString()) || TextUtils.isEmpty(p2.getText().toString()) ){
                    Toast.makeText(MainActivity.this,"Enter player names",Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                    Intent i=new Intent(MainActivity.this,game.class);
                    i.putExtra("pr1",p1.getText().toString());
                    i.putExtra("pr2", p2.getText().toString());
                    startActivity(i);
                }
            }
        });
    }
}
