package com.example.tictactoe;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class game extends AppCompatActivity implements View.OnClickListener {

    TextView ch,re,px1,px2;
    Button b[][]=new Button[3][3];
    AlertDialog.Builder builder;
    int yy=1;
    public static void imple(Button b,int y){
        if(y==1){
            b.setBackgroundColor(Color.BLUE);
            b.setText("O");
            b.setEnabled(false);

        }
        else{
            b.setBackgroundColor(Color.TRANSPARENT);
            b.setText("X");
            b.setEnabled(false);

        }
    }
    public static Boolean check(Button b[][],int u){
        int s[][]=new int[3][3];
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                String g=b[i][j].getText().toString();
                if(g.equals("X")){
                    s[i][j]=-1;
                }
                else if(g.equals("O")){
                    s[i][j]=1;
                }
                else{
                    s[i][j]=0;
                }

            }
        }
        if(u==1){
        if(s[0][0]+s[0][1]+s[0][2]==3  || s[1][0]+s[1][1]+s[1][2]==3 || s[2][0]+s[2][1]+s[2][2]==3 || s[0][0]+s[1][0]+s[2][0]==3 || s[0][1]+s[1][1]+s[2][1]==3 || s[0][2]+s[1][2]+s[2][2]==3 || s[0][0]+s[1][1]+s[2][2]==3 || s[0][2]+s[1][1]+s[2][0]==3){
            for(int i=0;i<3;i++){
                for(int j=0;j<3;j++){
                    b[i][j].setEnabled(false);
                }
            }
            return true;
        }
        else{
            return false;
        }}
        else if(u==2){
            if(s[0][0]+s[0][1]+s[0][2]==-3  || s[1][0]+s[1][1]+s[1][2]==-3 || s[2][0]+s[2][1]+s[2][2]==-3 || s[0][0]+s[1][0]+s[2][0]==-3 || s[0][1]+s[1][1]+s[2][1]==-3 || s[0][2]+s[1][2]+s[2][2]==-3 || s[0][0]+s[1][1]+s[2][2]==-3 || s[0][2]+s[1][1]+s[2][0]==-3){
                for(int i=0;i<3;i++){
                    for(int j=0;j<3;j++){
                        b[i][j].setEnabled(false);
                    }
                }
                return true;
            }
            else{
                return false;
            }
        }
        return  false;

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        ch=(TextView) findViewById(R.id.ch);
        px1=(TextView) findViewById(R.id.px1);
        px2=(TextView) findViewById(R.id.px2);
        re=(TextView) findViewById(R.id.re);
        b[0][0]=(Button) findViewById(R.id.b1);
        b[0][1]=(Button) findViewById(R.id.b2);
        b[0][2]=(Button) findViewById(R.id.b3);
        builder =new AlertDialog.Builder(this);
        b[1][0]=(Button) findViewById(R.id.b4);
        b[1][1]=(Button) findViewById(R.id.b5);
        b[1][2]=(Button) findViewById(R.id.b6);
        b[2][0]=(Button) findViewById(R.id.b7);
        b[2][1]=(Button) findViewById(R.id.b8);
        b[2][2]=(Button) findViewById(R.id.b9);
        Intent in=getIntent();
        px1.setText(in.getStringExtra("pr1"));
        px2.setText(in.getStringExtra("pr2"));
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                b[i][j].setOnClickListener(this);
            }
        }
    }






    @Override
    public void onClick(View v) {
        Boolean w;
        switch (v.getId()){
            case R.id.b1:
                imple(b[0][0],yy);
                 w=check(b,yy);
                if(w){
                    if(yy==1){
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 1")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 1");
                        Toast.makeText(game.this,"Winner is player 1",Toast.LENGTH_LONG).show();
                        return;

                    }
                    else{
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 2")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 2");
                        Toast.makeText(game.this,"Winner is player 2",Toast.LENGTH_LONG).show();
                        return;
                    }


                }
                else{
                    if(yy==1){
                        ch.setText("Chance for Player 2");
                        yy=2;
                    }
                    else{
                        ch.setText("Chance For Player 1");
                        yy=1;
                    }
                }


                break;
            case R.id.b2:
                imple(b[0][1],yy);
                w=check(b,yy);
                if(w){
                    if(yy==1){
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 1")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 1");
                        Toast.makeText(game.this,"Winner is player 1",Toast.LENGTH_LONG).show();
                        return;

                    }
                    else{
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 2")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 2");
                        Toast.makeText(game.this,"Winner is player 2",Toast.LENGTH_LONG).show();
                        return;
                    }

                }
                else{
                    if(yy==1){
                        ch.setText("Chance for Player 2");
                        yy=2;
                    }
                    else{
                        ch.setText("Chance For Player 1");
                        yy=1;
                    }
                }


                break;
            case R.id.b3:
                imple(b[0][2],yy);
                 w=check(b,yy);
                if(w){
                    if(yy==1){
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 1")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 1");
                        Toast.makeText(game.this,"Winner is player 1",Toast.LENGTH_LONG).show();
                        return;

                    }
                    else{
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 2")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 2");
                        Toast.makeText(game.this,"Winner is player 2",Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                else{
                    if(yy==1){
                        ch.setText("Chance for Player 2");
                        yy=2;
                    }
                    else{
                        ch.setText("Chance For Player 1");
                        yy=1;
                    }
                }


                break;
            case R.id.b4:
                imple(b[1][0],yy);
                 w=check(b,yy);
                if(w){
                    if(yy==1){
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 1")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 1");
                        Toast.makeText(game.this,"Winner is player 1",Toast.LENGTH_LONG).show();
                        return;

                    }
                    else{
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 2")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 2");
                        Toast.makeText(game.this,"Winner is player 2",Toast.LENGTH_LONG).show();
                        return;
                    }

                }
                else{
                    if(yy==1){
                        ch.setText("Chance for Player 2");
                        yy=2;
                    }
                    else{
                        ch.setText("Chance For Player 1");
                        yy=1;
                    }
                }


                break;
            case R.id.b5:
                imple(b[1][1],yy);
                w=check(b,yy);
                if(w){
                    if(yy==1){
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 1")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 1");
                        Toast.makeText(game.this,"Winner is player 1",Toast.LENGTH_LONG).show();
                        return;

                    }
                    else{
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 2")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 2");
                        Toast.makeText(game.this,"Winner is player 2",Toast.LENGTH_LONG).show();
                        return;
                    }

                }
                else{
                    if(yy==1){
                        ch.setText("Chance for Player 2");
                        yy=2;
                    }
                    else{
                        ch.setText("Chance For Player 1");
                        yy=1;
                    }
                }


                break;
            case R.id.b6:
                imple(b[1][2],yy);
                 w=check(b,yy);
                if(w){
                    if(yy==1){
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 1")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 1");
                        Toast.makeText(game.this,"Winner is player 1",Toast.LENGTH_LONG).show();
                        return;

                    }
                    else{
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 2")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 2");
                        Toast.makeText(game.this,"Winner is player 2",Toast.LENGTH_LONG).show();
                        return;
                    }

                }
                else{
                    if(yy==1){
                        ch.setText("Chance for Player 2");
                        yy=2;
                    }
                    else{
                        ch.setText("Chance For Player 1");
                        yy=1;
                    }
                }


                break;
            case R.id.b7:
                imple(b[2][0],yy);
                 w=check(b,yy);
                if(w){
                    if(yy==1){
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 1")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 1");
                        Toast.makeText(game.this,"Winner is player 1",Toast.LENGTH_LONG).show();
                        return;

                    }
                    else{
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 2")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 2");
                        Toast.makeText(game.this,"Winner is player 2",Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                else{
                    if(yy==1){
                        ch.setText("Chance for Player 2");
                        yy=2;
                    }
                    else{
                        ch.setText("Chance For Player 1");
                        yy=1;
                    }
                }


                break;
            case R.id.b8:
                imple(b[2][1],yy);
                 w=check(b,yy);
                if(w){
                    if(yy==1){
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 1")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 1");
                        Toast.makeText(game.this,"Winner is player 1",Toast.LENGTH_LONG).show();
                        return;

                    }
                    else{
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 2")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 2");
                        Toast.makeText(game.this,"Winner is player 2",Toast.LENGTH_LONG).show();
                        return;
                    }

                }
                else{
                    if(yy==1){
                        ch.setText("Chance for Player 2");
                        yy=2;
                    }
                    else{
                        ch.setText("Chance For Player 1");
                        yy=1;
                    }
                }


                break;
            case R.id.b9:
                imple(b[2][2],yy);
                w=check(b,yy);
                if(w){
                    if(yy==1){
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 1")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 1");
                        Toast.makeText(game.this,"Winner is player 1",Toast.LENGTH_LONG).show();
                        return;

                    }
                    else{
                        builder.setMessage("hi") .setTitle("hi");

                        builder.setMessage("Winner is player 2")
                                .setCancelable(false)
                                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                    }
                                })
                                .setNegativeButton("Play again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button

                                        Intent in=new Intent(game.this,game.class);
                                        startActivity(in);
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("");
                        alert.show();
                        re.setText("Winner is player 2");
                        Toast.makeText(game.this,"Winner is player 2",Toast.LENGTH_LONG).show();
                        return;
                    }

                }
                else{
                    if(yy==1){
                        ch.setText("Chance for Player 2");
                        yy=2;
                    }
                    else{
                        ch.setText("Chance For Player 1");
                        yy=1;
                    }
                }


                break;

            default:
                throw new IllegalStateException("Unexpected value: " + v.getId());
        }
    }
}

